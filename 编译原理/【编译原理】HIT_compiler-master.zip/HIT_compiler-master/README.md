# HIT_compiler
## 实验一：词法分析
使用了PyQt5来进行GUI的设计和自动生成代码，理论上讲，安装了PyQt5之后,直接运行Lab1文件夹下的Latex_UI_Launcher.py就可以: )

测试机器是一台mac， python版本是3.7，

<font color="#660000">注意：因为是在mac上测试的，所以中文的编码可能和windows不一样，可能会需要修改打开文件的编码方式ε-(´∀｀; )</font><br />

## 实验二:语法分析
使用的和实验一是一样的, 理论上讲, 安装了所有相关的包之后, 直接运行Lab2文件夹下面的Grammar_UI_Lancher.py就可以: )

测试机器同样是一台mac, python版本同样为3.7


