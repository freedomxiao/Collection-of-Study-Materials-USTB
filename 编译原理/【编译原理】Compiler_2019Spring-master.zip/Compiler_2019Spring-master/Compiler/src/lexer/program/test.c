int a;
a = 1 + 2;
int b;
int c;
c = 10;
b = c + 1;
int d;
d = c * 2;
int e;
e = 0;
int x;
int y;
y = 999;
int z;
z = 100;
while (a < b)
    if (c < d) x = y + z; else x = a + b;

a = b + c * (d + e);

if(a > b)
    c = d;

proc float function(float i){
    i = i + 1;
    return i;
}

int [2][3] list;
int c;
int i;
int j;
int d;
float h;
d = c + list[i][j];
list[i][j] = c;

d = h * c;

c[1][2] = d;
proc int function(int a, int c){
    a = c + 10;
    int d;
    return a;
}

