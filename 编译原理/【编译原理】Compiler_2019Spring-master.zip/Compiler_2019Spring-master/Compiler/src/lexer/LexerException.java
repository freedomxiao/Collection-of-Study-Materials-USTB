package lexer;

public class LexerException extends Exception {
    public LexerException(String errorMessage){
        super(errorMessage);
    }
}
