#include "ESP8266.h"

void AT_CMODE(){
	printf("AT+CMODE=1\r\n");
}

void AT_RST(){
	printf("AT+RST\r\n");
	delay_ms(1000);
}

void AT_CWJAP(){
	printf("AT+CWJAP,\"BINGGO\",\"Illyasviel200094\"\r\n");
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
}

void AT_ATKCLOUD(){
	printf("AT+ATKCLDSTA=\"97140252021805093352\",\"12345678\"\r\n");
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
//	delay_ms(1000);
//	delay_ms(1000);
}

void AT_init(){
	AT_CMODE();
	AT_RST();
	AT_CWJAP();
	AT_ATKCLOUD();
}
