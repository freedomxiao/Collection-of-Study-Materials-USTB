#include "timer.h"

void TIM4_Init(u16 arr,u16 prc)
{
	TIM_TimeBaseInitTypeDef TIMInitStruct;
	NVIC_InitTypeDef NVICInitStruct;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4,ENABLE);
	TIMInitStruct.TIM_ClockDivision=TIM_CKD_DIV1;
	TIMInitStruct.TIM_CounterMode=TIM_CounterMode_Up;
	TIMInitStruct.TIM_Period=arr;
	TIMInitStruct.TIM_Prescaler=prc;
	TIMInitStruct.TIM_RepetitionCounter=0;
	TIM_TimeBaseInit(TIM3,&TIMInitStruct);
	TIM_ITConfig(TIM4,TIM_IT_Update,ENABLE);
	
	NVICInitStruct.NVIC_IRQChannel=TIM4_IRQn;
	NVICInitStruct.NVIC_IRQChannelCmd=ENABLE;
	NVICInitStruct.NVIC_IRQChannelPreemptionPriority=0;
	NVICInitStruct.NVIC_IRQChannelSubPriority=1;
	NVIC_Init(&NVICInitStruct);
	

}

void PWM_init(u16 arr, u16 prc){
	TIM_TimeBaseInitTypeDef TIMInitStruct;
	GPIO_InitTypeDef GPIOInitStruct;
	TIM_OCInitTypeDef TIMOCInitStruct;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_AFIO,ENABLE);
	
	TIMInitStruct.TIM_ClockDivision=TIM_CKD_DIV1;
	TIMInitStruct.TIM_CounterMode=TIM_CounterMode_Up;
	TIMInitStruct.TIM_Period=arr;
	TIMInitStruct.TIM_Prescaler=prc;
	TIMInitStruct.TIM_RepetitionCounter=0;
	TIM_TimeBaseInit(TIM3,&TIMInitStruct);
	
	GPIOInitStruct.GPIO_Pin = GPIO_Pin_6;     
	GPIOInitStruct.GPIO_Mode = GPIO_Mode_AF_PP;        //���ù���,���츴��
	GPIOInitStruct.GPIO_Speed = GPIO_Speed_50MHz;	//�ٶ�50MHz
	GPIO_Init(GPIOA,&GPIOInitStruct); 
	
	TIMOCInitStruct.TIM_OCMode = TIM_OCMode_PWM1; //ѡ��ʱ��ģʽ:TIM������ȵ���ģʽ1
 	TIMOCInitStruct.TIM_OutputState = TIM_OutputState_Enable; //�Ƚ����ʹ��
	TIMOCInitStruct.TIM_OCPolarity = TIM_OCPolarity_Low; //�������:TIM����Ƚϼ��Ե�
	
	TIM_OC1Init(TIM3, &TIMOCInitStruct);  //����Tָ���Ĳ�����ʼ������TIM1 4OC1
	TIM_OC1PreloadConfig(TIM3, TIM_OCPreload_Enable);  //ʹ��TIM1��CCR1�ϵ�Ԥװ�ؼĴ���
	 TIM_ARRPreloadConfig(TIM3,ENABLE);//ARPEʹ�� 
//	TIM_CtrlPWMOutputs(TIM1,ENABLE);//�߼���ʱ����Ҫ
	TIM_Cmd(TIM3, ENABLE);  //ʹ��TIM1
}


void TIM4_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM4,TIM_IT_Update)==SET){
		printf("Ͷʳ���");
		TIM_SetCompare1(TIM3,195);
		TIM_Cmd(TIM4,DISABLE);
	}
	TIM_ClearITPendingBit(TIM4,TIM_IT_Update);
}
