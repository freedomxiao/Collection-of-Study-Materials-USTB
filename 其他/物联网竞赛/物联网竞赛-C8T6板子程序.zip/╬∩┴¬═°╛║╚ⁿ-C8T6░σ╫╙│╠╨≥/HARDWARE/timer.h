#ifndef		__TIM__
#define 	__TIM__
#include "stm32f10x.h"
#include "usart.h"
void TIM4_Init(u16 arr, u16 prc);
void PWM_init(u16 arr, u16 prc);


#endif