#ifndef __ESP8266__
#define __ESP8266__
#include "stm32f10x.h"
#include "delay.h"
#include "usart.h"
void AT_CMODE();				
void AT_RST();
void AT_CWJAP();
void AT_ATKCLOUD();
void AT_init();
#endif